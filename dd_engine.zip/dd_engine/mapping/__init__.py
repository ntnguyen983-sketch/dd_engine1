"""mapping — Giai đoạn 1: Cognitive Filter + Structural Mapping (S01-S04)."""

from .observable import Observation, SignalKind
from .tokenizer import tokenize
from .priority import (
    apply_first_observable_priority,
    select_minimal_representation,
    mai_hoa_normalize_pair,
    mai_hoa_normalize_active_line,
)
from .mapper import StructuralMapper

__all__ = [
    "Observation", "SignalKind", "tokenize",
    "apply_first_observable_priority", "select_minimal_representation",
    "mai_hoa_normalize_pair", "mai_hoa_normalize_active_line",
    "StructuralMapper",
]
