"""
mapping/mapper.py — Structural Mapping (Bước 3 Giai đoạn 1).

Kết hợp Tokenizer (Cognitive Filter) + 4 Quy tắc ưu tiên (mục 3.9) để chuyển
tín hiệu thô thành Hexagram, giao cho core.hexagram.build_hexagram*.
"""

from typing import Optional, Union

from .tokenizer import tokenize
from .priority import apply_first_observable_priority, mai_hoa_normalize_pair, mai_hoa_normalize_active_line
from ..core.hexagram import Hexagram, build_hexagram, build_hexagram_from_ambiguous_signal


class StructuralMapper:
    """
    Thực thi Giai đoạn 1 (Observation -> Cognitive Filter -> Structural Mapping)
    và bàn giao cho Hexagram Engine (S04) tạo Hexagram cuối cùng.
    """

    def map(self, raw_input: Union[str, int, float, list],
            gio: Optional[str] = None) -> Hexagram:
        """
        raw_input: tín hiệu thô (câu mô tả, số, hoặc list các tín hiệu).
        gio      : Địa chi giờ quan sát — nếu có, dùng công thức z chuẩn để
                   tính Hào động; nếu không, bồ khuyết bằng tín hiệu thứ 3
                   (nếu tồn tại) theo mod 6.

        Quy ước tối giản: 2 (hoặc 3) tín hiệu đầu tiên theo thứ tự xuất hiện
        (Quy tắc 1) lần lượt đóng vai trò Thượng quái, Hạ quái, [Hào động].
        """
        observations = tokenize(raw_input)
        observations = apply_first_observable_priority(observations)

        if len(observations) < 2:
            raise ValueError(
                "Cần tối thiểu 2 tín hiệu (Thượng quái, Hạ quái) để khởi quẻ; "
                f"chỉ nhận được {len(observations)}."
            )

        obs_thuong, obs_ha = observations[0], observations[1]
        upper, lower = mai_hoa_normalize_pair(obs_thuong, obs_ha)

        if len(observations) >= 3:
            active_line = mai_hoa_normalize_active_line(observations[2])
            return Hexagram(upper=upper, lower=lower, active_line=active_line)

        if gio is not None:
            return build_hexagram(upper, lower, gio)

        return build_hexagram_from_ambiguous_signal(
            tong_dinh_luong_thuong=to_int_or_hash(obs_thuong.value),
            tong_dinh_luong_ha=to_int_or_hash(obs_ha.value),
            tong_dinh_luong_hao=to_int_or_hash(obs_thuong.value) + to_int_or_hash(obs_ha.value),
        )


def to_int_or_hash(value) -> int:
    if isinstance(value, int):
        return value
    return sum(ord(c) for c in str(value))
