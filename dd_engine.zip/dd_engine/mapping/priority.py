"""
mapping/priority.py — Quy tắc ưu tiên ánh xạ dữ liệu mơ hồ (mục 3.9).

Quy tắc 1: First Observable Priority — ưu tiên tín hiệu xuất hiện sớm.
Quy tắc 2: Minimal Representation Priority — Lượng > Hình > Ý nghĩa đơn.
Quy tắc 3: Semantic Cluster Priority — giữ nguyên cụm ý hoàn chỉnh (xử lý ở tokenizer).
Quy tắc 4: Mai Hoa Normalization — chuẩn hóa mod 8 / mod 6 (đặt tại core.hexagram).
"""

from typing import List

from .observable import Observation, SignalKind
from ..core.hexagram import normalize_to_quai_so, normalize_to_hao_dong

# Thứ tự ưu tiên biểu diễn tối giản (Quy tắc 2), số nhỏ hơn = ưu tiên cao hơn
_KIND_PRIORITY = {
    SignalKind.QUANTITY: 0,
    SignalKind.SHAPE: 1,
    SignalKind.SEMANTIC: 2,
}


def apply_first_observable_priority(observations: List[Observation]) -> List[Observation]:
    """Quy tắc 1: sắp xếp theo đúng thứ tự xuất hiện — KHÔNG thay bằng tín hiệu muộn hơn."""
    return sorted(observations, key=lambda o: o.order)


def select_minimal_representation(observations: List[Observation]) -> Observation:
    """
    Quy tắc 2: trong một nhóm tín hiệu cùng ứng viên cho một vai trò,
    chọn tín hiệu có mức biểu diễn tối giản nhất: Quantity > Shape > Semantic.
    """
    if not observations:
        raise ValueError("Danh sách Observation rỗng, không thể chọn.")
    return sorted(observations, key=lambda o: (_KIND_PRIORITY[o.kind], o.order))[0]


def semantic_value_to_number(value: str) -> int:
    """
    Ánh xạ tối thiểu Shape/Semantic -> số nguyên dùng cho chuẩn hóa Mai Hoa,
    dựa trên tổng mã ký tự (định lượng khách quan hóa một chuỗi định tính).
    Đây là bước 'hạ xuống Tham số khởi tạo' theo A5 — có thể thay bằng bảng
    tra chuyên biệt khi có thực chứng.
    """
    return sum(ord(ch) for ch in value)


def to_quantity(observation: Observation) -> int:
    """Chuẩn hóa một Observation bất kỳ về giá trị định lượng (int)."""
    if observation.kind == SignalKind.QUANTITY:
        return int(observation.value)
    return semantic_value_to_number(str(observation.value))


def mai_hoa_normalize_pair(obs_thuong: Observation, obs_ha: Observation) -> tuple:
    """Quy tắc 4: chuẩn hóa cặp tín hiệu Thượng/Hạ về (Quái số, Quái số)."""
    upper = normalize_to_quai_so(to_quantity(obs_thuong))
    lower = normalize_to_quai_so(to_quantity(obs_ha))
    return upper, lower


def mai_hoa_normalize_active_line(obs_hao: Observation) -> int:
    """Quy tắc 4: chuẩn hóa tín hiệu Hào động -> Hào động (1..6)."""
    return normalize_to_hao_dong(to_quantity(obs_hao))
