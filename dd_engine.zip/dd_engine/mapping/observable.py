"""
mapping/observable.py — Cấu trúc dữ liệu cho Observation (Giai đoạn 1, Bước 1-2).

Observation là tín hiệu thô sau khi qua Cognitive Filter (Bộ lọc Sát-na),
sẵn sàng cho Structural Mapping.
"""

from dataclasses import dataclass
from enum import Enum
from typing import Optional, Union


class SignalKind(Enum):
    """Loại tín hiệu, dùng cho quy tắc Minimal Representation Priority (3.9)."""
    QUANTITY = "quantity"    # có số lượng rõ ràng (Lượng)
    SHAPE = "shape"          # hình/tượng trực tiếp (Hình)
    SEMANTIC = "semantic"    # cụm ý ngữ nghĩa đơn (Ý nghĩa đơn)


@dataclass
class Observation:
    """
    Một tín hiệu quan sát đã qua lọc.
    order: thứ tự xuất hiện trong dòng tiếp nhận (dùng cho First Observable Priority).
    kind : loại tín hiệu (Quantity/Shape/Semantic).
    value: giá trị — số (int) nếu Quantity, hoặc chuỗi mô tả nếu Shape/Semantic.
    role : vai trò cấu trúc nếu đã biết ('upper' | 'lower' | 'active_line' | None).
    """
    order: int
    kind: SignalKind
    value: Union[int, str]
    role: Optional[str] = None

    def __repr__(self):
        return f"Observation(#{self.order}, {self.kind.value}, {self.value!r}, role={self.role})"
