"""
mapping/tokenizer.py — Cognitive Filter (Bước 2 của Giai đoạn 1).

Chuyển tín hiệu thô (raw string / số / list) thành danh sách Observation,
tuân thủ Quy tắc 3 (Semantic Cluster Priority): không tách cụm ý hoàn chỉnh
như "chia ly" thành "chia" + "ly".
"""

import re
from typing import List, Union

from .observable import Observation, SignalKind

# Các cụm ý được coi là một khối ngữ nghĩa duy nhất, không tách nhỏ.
# Có thể mở rộng danh sách này (nguyên lý Mở rộng của Firewall Tầng Khí).
SEMANTIC_CLUSTERS = [
    "chia ly", "hội tụ", "tan vỡ", "sum họp", "biến động", "an định",
]


def tokenize(raw_input: Union[str, int, float, list]) -> List[Observation]:
    """
    Cognitive Filter đơn giản:
    - Nếu input là số (int/float) -> 1 Observation dạng QUANTITY.
    - Nếu input là list -> mỗi phần tử được tokenize tuần tự, giữ nguyên order.
    - Nếu input là chuỗi -> quét cụm ngữ nghĩa đã biết trước (giữ nguyên khối),
      sau đó tách phần còn lại thành số (QUANTITY) hoặc từ đơn (SHAPE/SEMANTIC).
    """
    if isinstance(raw_input, (int, float)):
        return [Observation(order=0, kind=SignalKind.QUANTITY, value=int(raw_input))]

    if isinstance(raw_input, list):
        obs: List[Observation] = []
        order = 0
        for item in raw_input:
            for o in tokenize(item):
                obs.append(Observation(order=order, kind=o.kind, value=o.value))
                order += 1
        return obs

    if not isinstance(raw_input, str):
        raise TypeError(f"Không hỗ trợ kiểu input: {type(raw_input)}")

    text = raw_input.strip()
    observations: List[Observation] = []
    order = 0
    remaining = text

    # Bước 1: trích cụm ngữ nghĩa hoàn chỉnh trước (Quy tắc 3)
    for cluster in SEMANTIC_CLUSTERS:
        if cluster in remaining:
            observations.append(Observation(order=order, kind=SignalKind.SEMANTIC, value=cluster))
            order += 1
            remaining = remaining.replace(cluster, " ")

    # Bước 2: tách số (Quantity) — ưu tiên cao nhất theo Minimal Representation
    for num in re.findall(r"\d+", remaining):
        observations.append(Observation(order=order, kind=SignalKind.QUANTITY, value=int(num)))
        order += 1
    remaining = re.sub(r"\d+", " ", remaining)

    # Bước 3: phần chữ còn lại -> coi là Shape/Hình tượng (từng từ)
    for word in remaining.split():
        observations.append(Observation(order=order, kind=SignalKind.SHAPE, value=word))
        order += 1

    # Sắp lại theo thứ tự xuất hiện thực tế trong câu gốc (First Observable Priority)
    observations.sort(key=lambda o: text.find(str(o.value)) if str(o.value) in text else o.order)
    for i, o in enumerate(observations):
        o.order = i

    return observations
