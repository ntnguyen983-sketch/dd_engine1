"""
strategy/engine.py — StrategyEngine, cài đặt Tầng S08 (Actionable, mục
Phụ lục 5.4 Thành phần 6: "Ma trận quyết định, Điều kiện If-Then").

recommend() nhận Snapshot + Analysis + Meaning (đã qua Firewall S06 và
diễn dịch S07) và sinh quyết định hành động dạng {action, confidence,
reason}. Bảng luật If-Then dưới đây là Hyperparameter (A5) — cần hiệu
chỉnh dần qua Self-Correction Loop (S11) khi có thực chứng.
"""

from dataclasses import dataclass, field
from typing import List

from ..core.plugin import StrategyPlugin
from ..core.snapshot import Snapshot
from ..reason.analysis import Analysis
from ..semantic.engine import Meaning
from ..semantic.rules import SemanticLabel

# Hành động mặc định theo từng nhãn ngữ nghĩa S07 (chưa xét stability/conflict)
_DEFAULT_ACTION = {
    SemanticLabel.TU.value: "ACT",
    SemanticLabel.HOP.value: "HOLD",
    SemanticLabel.TAN.value: "WAIT",
    SemanticLabel.LY.value: "AVOID",
    SemanticLabel.HIEN.value: "ACT",
    SemanticLabel.AN.value: "WAIT",
    SemanticLabel.TRUNG_TINH.value: "WAIT",
}


@dataclass
class Decision:
    action: str                 # "ACT" | "WAIT" | "HOLD" | "AVOID"
    confidence: float           # 0..1
    reason: List[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {"action": self.action, "confidence": self.confidence, "reason": self.reason}


class StrategyEngine(StrategyPlugin):
    """Cài đặt mặc định Tầng S08. Thay thế bằng register_strategy() nếu cần
    một Rule Engine/LLM khác mà không đụng tới DCGFEngine (UK8)."""

    def recommend(self, snapshot: Snapshot, analysis: Analysis, meaning: Meaning) -> Decision:
        reasons: List[str] = []
        action = _DEFAULT_ACTION.get(meaning.label, "WAIT")
        reasons.append(f"Nhãn S07 = {meaning.label} -> hành động mặc định {action}.")

        confidence = analysis.stability
        reasons.append(f"Mức ổn định (stability) = {analysis.stability}.")

        # Hạ cấp hành động nếu có xung khắc Ngũ hành hoặc độ ổn định thấp
        if analysis.conflict:
            confidence = max(0.0, confidence - 0.2)
            reasons.append(
                f"Xung khắc Ngũ hành giữa Thượng ({analysis.upper_element}) và "
                f"Hạ ({analysis.lower_element}) -> hạ độ tin cậy."
            )
            if action == "ACT":
                action = "HOLD"
                reasons.append("Vì có xung khắc, hạ hành động từ ACT xuống HOLD.")

        if analysis.trend == "Declining" and action == "ACT":
            action = "HOLD"
            reasons.append("Xu thế đang Declining -> hạ hành động từ ACT xuống HOLD.")

        if confidence < 0.3 and action in ("ACT", "HOLD"):
            action = "WAIT"
            reasons.append("Độ tin cậy quá thấp (<0.3) -> chuyển hành động về WAIT.")

        confidence = round(max(0.0, min(1.0, confidence)), 3)

        return Decision(action=action, confidence=confidence, reason=reasons)
