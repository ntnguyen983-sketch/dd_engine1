"""
reason/analysis.py — Analyze(): bước trung gian giữa Runtime (S06) và
Semantic Engine (S07).

Đầu vào: Snapshot (Hexagram + VectorKhi + mạng lưới).
Đầu ra : Analysis — các chỉ số động lực học THUẦN TOÁN HỌC (ngũ hành của
Quái, xu thế theo dấu D, mức ổn định theo I/D, có xung khắc ngũ hành hay
không). Đây vẫn là dữ liệu định lượng/cấu trúc — CHƯA phải diễn giải ý
nghĩa (Career/Finance/Relationship...); việc đó thuộc về SemanticEngine.interpret().
"""

from dataclasses import dataclass
from typing import List

from ..core.bagua import Quai, BAGUA_TABLE
from ..core.snapshot import Snapshot

# Ngũ hành tương khắc: khóa khắc giá trị (Kim khắc Mộc, Mộc khắc Thổ, ...)
NGU_HANH_TUONG_KHAC = {
    "Kim": "Mộc", "Mộc": "Thổ", "Thổ": "Thủy", "Thủy": "Hỏa", "Hỏa": "Kim",
}


@dataclass
class Analysis:
    trend: str                 # "Growing" | "Declining" | "Stable"
    stability: float            # 0..1, càng cao càng ổn định
    dominant_element: str       # Ngũ hành chiếm ưu thế (Kim/Mộc/Thủy/Hỏa/Thổ)
    upper_element: str
    lower_element: str
    conflict: bool              # có xung khắc Ngũ hành giữa Thượng/Hạ quái không
    vector_khi: List[float]     # [S, D, I, F, T] mang theo để truy vết (A4)

    def to_dict(self) -> dict:
        return {
            "trend": self.trend,
            "stability": self.stability,
            "dominant_element": self.dominant_element,
            "upper_element": self.upper_element,
            "lower_element": self.lower_element,
            "conflict": self.conflict,
            "vector_khi": self.vector_khi,
        }


def _is_conflict(a: str, b: str) -> bool:
    return NGU_HANH_TUONG_KHAC.get(a) == b or NGU_HANH_TUONG_KHAC.get(b) == a


def analyze(snapshot: Snapshot) -> Analysis:
    if snapshot.hexagram is None or snapshot.vector_khi is None:
        raise ValueError("Snapshot thiếu hexagram hoặc vector_khi — hãy observe() trước.")

    hexagram = snapshot.hexagram
    S, D, I, F, T = snapshot.vector_khi

    upper_hanh = BAGUA_TABLE[Quai(hexagram.upper)]["ngu_hanh"]
    lower_hanh = BAGUA_TABLE[Quai(hexagram.lower)]["ngu_hanh"]

    # Trục ưu tiên tối giản (A5 — hyperparameter, có thể tinh chỉnh sau):
    # hào động thuộc Thượng quái (S>=0.5) -> Thượng lấn át; ngược lại Hạ lấn át.
    dominant_element = upper_hanh if S >= 0.5 else lower_hanh

    if D > 0.05:
        trend = "Growing"
    elif D < -0.05:
        trend = "Declining"
    else:
        trend = "Stable"

    # Ổn định cao khi mật độ tương tác (I) vừa phải/cao và biến động (D) thấp,
    # trừ hao khi có xung động lực F quá lớn.
    conflict = _is_conflict(upper_hanh, lower_hanh)
    stability = round(max(0.0, min(1.0, 0.5 * I + 0.5 * (1 - abs(D)) - (0.15 if conflict else 0.0))), 3)

    return Analysis(
        trend=trend,
        stability=stability,
        dominant_element=dominant_element,
        upper_element=upper_hanh,
        lower_element=lower_hanh,
        conflict=conflict,
        vector_khi=list(snapshot.vector_khi),
    )
