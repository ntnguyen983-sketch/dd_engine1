"""
reason/node.py — Schema Dữ Liệu Duyên (S02, mục 3.1.A).

Identity_ID      : điểm quy chiếu định vị truy vết (không đại diện thực thể độc lập)
Tu_Kien [H,L,K,T]: Hướng, Lực, Khí, Thế
Relation_Edges   : liên kết trực tiếp/gián tiếp tới các Duyên khác (danh sách Edge id)
Momentum_Value   : xung lực nội tại tích lũy (M_t, xem A2 — chặn trên 1.0)
History_Log      : chuỗi trạng thái biến đổi trước đó
"""

from dataclasses import dataclass, field
from typing import List, Tuple


@dataclass
class TuKien:
    """Tứ Kiện: Hướng (Direction), Lực (Force), Khí (State), Thế (Context)."""
    huong: float = 0.0
    luc: float = 0.0
    khi: float = 0.0
    the: float = 0.0

    def as_tuple(self) -> Tuple[float, float, float, float]:
        return (self.huong, self.luc, self.khi, self.the)


@dataclass
class DuyenNode:
    identity_id: str
    tu_kien: TuKien = field(default_factory=TuKien)
    relation_edges: List[str] = field(default_factory=list)   # danh sách edge_id
    momentum_value: float = 0.0
    history_log: List[str] = field(default_factory=list)
    existence: float = 1.0   # E ∈ [0,1], mức độ hiện hữu (Tiên đề A1)

    def __post_init__(self):
        if not 0.0 <= self.existence <= 1.0:
            raise ValueError("existence (E) phải trong [0,1] — Tiên đề A1")

    def is_active(self, force_threshold: float = 1e-3) -> bool:
        """Điều kiện hiệu lực đơn giản hóa: còn Lực đáng kể và existence > 0."""
        return self.existence > 0.0 and abs(self.tu_kien.luc) > force_threshold

    def log_state(self, note: str) -> None:
        self.history_log.append(note)

    def to_dict(self) -> dict:
        return {
            "identity_id": self.identity_id,
            "tu_kien": self.tu_kien.as_tuple(),
            "relation_edges": list(self.relation_edges),
            "momentum_value": self.momentum_value,
            "existence": self.existence,
        }
