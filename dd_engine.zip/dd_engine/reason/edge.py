"""
reason/edge.py — Edge trong PGL (Primitive Graph Language, mục 3.1.B).

PGL = {Node(V), Edge(E), Weight(W ∈ [-1,1]), Momentum(M), Existence(E ∈ [0,1]),
       Topology(T), Time(T), Observer(O), Evidence(ε), Uncertainty(σ)}

Module này cài đặt thành phần Edge + Weight.
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Optional


class RelationType(Enum):
    """Các loại quan hệ tương tác cơ bản (mục 1.3.F Quy Luật Tương Tác)."""
    TUONG_HO = "tuong_ho"       # tương hỗ
    CONG_HUONG = "cong_huong"   # cộng hưởng
    XUNG_KHAC = "xung_khac"     # xung khắc
    TRIET_TIEU = "triet_tieu"   # triệt tiêu
    CHUYEN_HOA = "chuyen_hoa"   # chuyển hóa
    DONG_TON_TAI = "dong_ton_tai"  # đồng tồn tại (kể cả mâu thuẫn)


@dataclass
class Edge:
    edge_id: str
    source_id: str
    target_id: str
    weight: float                       # W ∈ [-1, 1]
    relation_type: RelationType = RelationType.TUONG_HO
    uncertainty: float = 0.0            # σ, xem A8 / UK4
    evidence: Optional[str] = None      # nguồn dữ liệu phục vụ truy vết (A4)

    def __post_init__(self):
        if not -1.0 <= self.weight <= 1.0:
            raise ValueError("weight (W) phải trong [-1, 1] — theo đặc tả PGL")
        if not 0.0 <= self.uncertainty <= 1.0:
            raise ValueError("uncertainty (σ) phải trong [0, 1]")

    def to_dict(self) -> dict:
        return {
            "edge_id": self.edge_id,
            "source_id": self.source_id,
            "target_id": self.target_id,
            "weight": self.weight,
            "relation_type": self.relation_type.value,
            "uncertainty": self.uncertainty,
            "evidence": self.evidence,
        }
