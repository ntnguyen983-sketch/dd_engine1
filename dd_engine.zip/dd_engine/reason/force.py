"""
reason/force.py — Toán Tử Tầng Khí: Vectơ Khí 5 chiều (mục 3.2) và
Lực / Hướng / Thế phái sinh từ mạng lưới Duyên (Node/Edge).

Vector_Khi = [S, D, I, F, T]
  S: Spatial Index        — vị trí hào động (0.0 / 0.5 / 1.0)
  D: Directional Derivative — hướng biến đổi Âm<->Dương, D ∈ [-1, 1]
  I: Interaction Density  — mật độ liên kết thực tế / tối đa
  F: Force / Momentum Scalar — xung lực tổng hợp từ mạng lưới
  T: Temporal Phase       — nhịp thời gian / pha đóng-mở

Firewall (mục 2.3): tầng này KHÔNG được gán nhãn Cát/Hung hay ngữ nghĩa
(A3 — Tính Phi ngữ nghĩa của Khí). Chỉ xuất số liệu hình học/toán học thuần túy.
"""

from dataclasses import dataclass
from typing import Dict, List

from ..core.hexagram import Hexagram
from .edge import Edge
from .node import DuyenNode


@dataclass
class VectorKhi:
    S: float
    D: float
    I: float
    F: float
    T: float

    def as_list(self) -> List[float]:
        return [self.S, self.D, self.I, self.F, self.T]

    def to_dict(self) -> dict:
        return {"S": self.S, "D": self.D, "I": self.I, "F": self.F, "T": self.T}


def compute_S(hexagram: Hexagram) -> float:
    """S theo vị trí hào động — đã cài trong Hexagram.spatial_index()."""
    return hexagram.spatial_index()


def compute_D(hexagram: Hexagram, psi: float = 1.0) -> float:
    """
    D = ΔH · ψ
    ΔH = +1 nếu hào động Âm(0) -> Dương(1) (Tiến Dương hóa)
    ΔH = -1 nếu hào động Dương(1) -> Âm(0) (Thoái Âm hóa)
    psi: hệ số khuếch đại — Hyperparameter (A5), mặc định 1.0.
    """
    idx = hexagram.active_line - 1
    goc_bit = hexagram.bits[idx]
    bien = hexagram.bien_quai()
    bien_bit = bien.bits[idx]
    delta_h = 1 if (goc_bit == 0 and bien_bit == 1) else -1
    d = delta_h * psi
    return max(-1.0, min(1.0, d))


def compute_I(nodes: Dict[str, DuyenNode], edges: List[Edge]) -> float:
    """
    I = (số liên kết thực tế) / (số liên kết tối đa có thể trong mạng SIE).
    Số liên kết tối đa dùng công thức đồ thị đầy đủ: n·(n-1)/2.
    """
    n = len(nodes)
    max_edges = n * (n - 1) / 2 if n > 1 else 1
    actual = len(edges)
    return max(0.0, min(1.0, actual / max_edges))


def compute_F(edges: List[Edge], base_momentum: float = 0.0) -> float:
    """
    F: xung lực tổng hợp — tổng trị tuyệt đối trọng số các Edge cộng với
    Momentum nền, chuẩn hóa về khoảng hợp lý bằng hàm bão hòa đơn giản.
    """
    if not edges:
        raw = base_momentum
    else:
        raw = base_momentum + sum(abs(e.weight) for e in edges) / len(edges)
    # bão hòa mềm về [0, +inf) nhưng giữ thang đo dễ so sánh
    return round(raw, 6)


def compute_T(active_line: int, momentum: float) -> float:
    """
    T: Nhịp thời gian / pha đóng-mở, xấp xỉ hóa bằng vị trí hào (chu kỳ 6)
    kết hợp Momentum hiện tại — hào lẻ = pha mở, hào chẵn = pha đóng.
    """
    phase_base = 1.0 if active_line % 2 == 1 else 0.0
    return round((phase_base + momentum) / 2, 6)


def compute_vector_khi(hexagram: Hexagram, nodes: Dict[str, DuyenNode],
                        edges: List[Edge], momentum: float = 0.0,
                        psi: float = 1.0) -> VectorKhi:
    """Tính đầy đủ Vectơ Khí 5 chiều từ Quẻ + mạng lưới Duyên hiện tại."""
    return VectorKhi(
        S=compute_S(hexagram),
        D=compute_D(hexagram, psi=psi),
        I=compute_I(nodes, edges),
        F=compute_F(edges, base_momentum=momentum),
        T=compute_T(hexagram.active_line, momentum),
    )
