"""
core/bagua.py — Bảng tra Bát Quái (8 Quái nguyên thủy) & Địa Chi.
Nền tảng dữ liệu tĩnh dùng chung cho toàn hệ thống DCGF.
"""

from enum import IntEnum
from typing import Tuple


class Quai(IntEnum):
    KIEN = 1   # Càn - Trời
    DOAI = 2   # Đoài - Đầm
    LY = 3     # Ly - Hỏa
    CHAN = 4   # Chấn - Sấm
    TON = 5    # Tốn - Gió
    KHAM = 6   # Khảm - Nước
    CAN = 7    # Cấn - Núi
    KHON = 8   # Khôn - Đất


# bits: (hào dưới, hào giữa, hào trên); 1 = Dương, 0 = Âm
BAGUA_TABLE = {
    Quai.KIEN: {"name": "Càn",  "hinh_tuong": "Trời", "bits": (1, 1, 1), "ngu_hanh": "Kim"},
    Quai.DOAI: {"name": "Đoài", "hinh_tuong": "Đầm",  "bits": (1, 1, 0), "ngu_hanh": "Kim"},
    Quai.LY:   {"name": "Ly",   "hinh_tuong": "Hỏa",  "bits": (1, 0, 1), "ngu_hanh": "Hỏa"},
    Quai.CHAN: {"name": "Chấn", "hinh_tuong": "Sấm",  "bits": (1, 0, 0), "ngu_hanh": "Mộc"},
    Quai.TON:  {"name": "Tốn",  "hinh_tuong": "Gió",  "bits": (0, 1, 1), "ngu_hanh": "Mộc"},
    Quai.KHAM: {"name": "Khảm", "hinh_tuong": "Nước", "bits": (0, 1, 0), "ngu_hanh": "Thủy"},
    Quai.CAN:  {"name": "Cấn",  "hinh_tuong": "Núi",  "bits": (0, 0, 1), "ngu_hanh": "Thổ"},
    Quai.KHON: {"name": "Khôn", "hinh_tuong": "Đất",  "bits": (0, 0, 0), "ngu_hanh": "Thổ"},
}

DIA_CHI = ["Tý", "Sửu", "Dần", "Mão", "Thìn", "Tỵ",
           "Ngọ", "Mùi", "Thân", "Dậu", "Tuất", "Hợi"]


def gio_to_index(gio: str) -> int:
    """Tên Địa chi giờ -> số thứ tự 1..12 (Tý=1,...,Hợi=12)."""
    try:
        return DIA_CHI.index(gio) + 1
    except ValueError:
        raise ValueError(f"Giờ không hợp lệ: '{gio}'. Phải thuộc {DIA_CHI}")


def bits_to_quai(bits: Tuple[int, int, int]) -> int:
    for quai, info in BAGUA_TABLE.items():
        if info["bits"] == bits:
            return int(quai)
    raise ValueError(f"Không tìm thấy Quái khớp bits={bits}")
