"""
core/plugin.py — Giao diện Plugin cho DCGFEngine.

Cho phép thay thế SemanticEngine, StrategyEngine, hay gắn thêm
Predictor/LLM mà KHÔNG sửa DCGFEngine (nguyên tắc UK8 — Extensibility:
mọi hệ tri thức mới chỉ cần xây Adapter/Decoder tuân chuẩn, không đụng Lõi).
"""

from abc import ABC, abstractmethod
from typing import Any


class SemanticPlugin(ABC):
    """Tương ứng Tầng S07 — Diễn dịch ngữ nghĩa. KHÔNG được truy cập trực
    tiếp dữ liệu thô, chỉ nhận Snapshot (đã đóng băng) + Analysis."""

    @abstractmethod
    def interpret(self, snapshot: Any, analysis: Any) -> Any:
        ...


class StrategyPlugin(ABC):
    """Tương ứng Tầng S08 — sinh khuyến nghị/quyết định hành động."""

    @abstractmethod
    def recommend(self, snapshot: Any, analysis: Any, meaning: Any) -> Any:
        ...


class PredictorPlugin(ABC):
    """Plugin dự báo mở rộng (vd. mô hình học máy, GNN...) — tùy chọn,
    không bắt buộc trong pipeline run() mặc định."""

    @abstractmethod
    def predict(self, snapshot: Any, analysis: Any) -> Any:
        ...


class LLMPlugin(ABC):
    """Plugin bọc một LLM (GPT, Local LLM...) dùng ở tầng Human Summary
    (Thành phần 5, S12) — KHÔNG được phép quay ngược sửa Kernel/Snapshot."""

    @abstractmethod
    def generate(self, prompt: str, context: Any = None) -> str:
        ...
