"""core — Tầng Lõi: Bát Quái, Hexagram Engine, Snapshot–Kernel–Runtime, Plugin interfaces."""

from .bagua import Quai, BAGUA_TABLE, DIA_CHI, gio_to_index, bits_to_quai
from .hexagram import (
    Hexagram,
    build_hexagram,
    build_hexagram_from_ambiguous_signal,
    calc_active_line_z,
    normalize_to_quai_so,
    normalize_to_hao_dong,
)
from .snapshot import Snapshot
from .runtime import Kernel, Runtime, TickRecord
from .plugin import SemanticPlugin, StrategyPlugin, PredictorPlugin, LLMPlugin

__all__ = [
    "Quai", "BAGUA_TABLE", "DIA_CHI", "gio_to_index", "bits_to_quai",
    "Hexagram", "build_hexagram", "build_hexagram_from_ambiguous_signal",
    "calc_active_line_z", "normalize_to_quai_so", "normalize_to_hao_dong",
    "Snapshot", "Kernel", "Runtime", "TickRecord",
    "SemanticPlugin", "StrategyPlugin", "PredictorPlugin", "LLMPlugin",
]
