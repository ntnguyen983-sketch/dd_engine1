"""
core/runtime.py — Toán tử Kernel K và Runtime (mục 3.3).

K: S_t -> S_{t+1}      (Transition Operator, Stateless)
Runtime = {S0 -> S1 -> S2 -> ...}   (chuỗi lặp toán tử K)

Tuân thủ A2 (Nội suy hao Động năng): nếu không có input mới, Momentum suy
hao đơn điệu; nếu có input mới, Momentum tăng nhưng bị chặn trên bởi 1.0.
"""

from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional

from .snapshot import Snapshot

MOMENTUM_MAX = 1.0
MOMENTUM_DECAY = 0.05  # hằng số suy hao mặc định, có thể override làm hyperparameter (A5)


@dataclass
class TickRecord:
    """
    Bản ghi đầy đủ của một chu kỳ quan sát: Snapshot + Analysis + Meaning +
    Decision, tách biệt khỏi Snapshot gốc để giữ Snapshot 'sạch' (không mang
    diễn giải), đồng thời cho phép truy vết ngược 'quẻ hôm qua đã luận gì,
    đã khuyến nghị gì, kết quả thực tế ra sao' — nền tảng cho tự đánh giá (S11).
    """
    tick: int
    snapshot: Snapshot
    analysis: Optional[Any] = None
    meaning: Optional[Any] = None
    decision: Optional[Any] = None
    actual_outcome: Optional[Any] = None  # ghi nhận thực chứng sau này (Thành phần 6, S12)

    def to_dict(self) -> dict:
        return {
            "tick": self.tick,
            "snapshot": self.snapshot.to_dict(),
            "analysis": getattr(self.analysis, "to_dict", lambda: self.analysis)(),
            "meaning": getattr(self.meaning, "to_dict", lambda: self.meaning)(),
            "decision": getattr(self.decision, "to_dict", lambda: self.decision)(),
            "actual_outcome": self.actual_outcome,
        }


class Kernel:
    """Lớp toán tử duy nhất được phép biến đổi Snapshot (A6)."""

    @staticmethod
    def transition(snapshot: Snapshot, inputs: Optional[Dict[str, Any]] = None,
                    decay: float = MOMENTUM_DECAY) -> Snapshot:
        """
        Áp dụng một bước chuyển trạng thái S_t -> S_{t+1}.
        inputs: dict tùy ý mô tả tác động ngoại lai lên hệ (Input_new trong A2).
                Ví dụ: {"hexagram": Hexagram(...), "momentum_delta": 0.2,
                        "nodes": {...}, "edges": [...]}
        """
        inputs = inputs or {}
        nxt = snapshot.clone_for_next_tick()

        # A2: suy hao động năng nếu không có input mới, tăng có chặn nếu có
        if inputs:
            delta = float(inputs.get("momentum_delta", 0.0))
            nxt.momentum = min(MOMENTUM_MAX, nxt.momentum + delta)
        else:
            nxt.momentum = max(0.0, nxt.momentum - decay)

        if "hexagram" in inputs:
            nxt.hexagram = inputs["hexagram"]
        if "nodes" in inputs:
            nxt.nodes.update(inputs["nodes"])
        if "edges" in inputs:
            nxt.edges.extend(inputs["edges"])
        if "vector_khi" in inputs:
            nxt.vector_khi = inputs["vector_khi"]

        nxt.history_log.append(f"tick {snapshot.tick}->{nxt.tick}: inputs={list(inputs.keys())}")
        return nxt


class Runtime:
    """
    Chuỗi Snapshot theo thời gian: Runtime = {S0, S1, S2, ...}.
    Runtime không giữ state nào ngoài danh sách Snapshot đã vật chất hóa
    (Implementation-Neutral Time Travel: rollback/replay chỉ đơn thuần là
    di chuyển con trỏ trong danh sách này).
    """

    def __init__(self, initial: Optional[Snapshot] = None):
        self.history: List[Snapshot] = [initial or Snapshot(tick=0)]
        self.records: Dict[int, TickRecord] = {}   # tick -> TickRecord (Analysis/Meaning/Decision)

    @property
    def current(self) -> Snapshot:
        return self.history[-1]

    def record(self, tick: int, analysis: Any = None, meaning: Any = None,
               decision: Any = None) -> TickRecord:
        """Gắn Analysis/Meaning/Decision vào Snapshot của một tick cụ thể."""
        snapshot = next((s for s in self.history if s.tick == tick), None)
        if snapshot is None:
            raise ValueError(f"Không tìm thấy Snapshot với tick={tick}")
        rec = self.records.get(tick) or TickRecord(tick=tick, snapshot=snapshot)
        if analysis is not None:
            rec.analysis = analysis
        if meaning is not None:
            rec.meaning = meaning
        if decision is not None:
            rec.decision = decision
        self.records[tick] = rec
        return rec

    def get_record(self, tick: int) -> Optional[TickRecord]:
        return self.records.get(tick)

    def set_actual_outcome(self, tick: int, outcome: Any) -> TickRecord:
        """Ghi nhận thực chứng sau này (Thành phần 6 của Output S12) để phục vụ S11."""
        rec = self.records.get(tick)
        if rec is None:
            raise ValueError(f"Chưa có TickRecord cho tick={tick}, hãy record() trước.")
        rec.actual_outcome = outcome
        return rec

    def tick(self, inputs: Optional[Dict[str, Any]] = None) -> Snapshot:
        """Sinh Snapshot kế tiếp bằng Kernel.transition và lưu vào history."""
        nxt = Kernel.transition(self.current, inputs)
        self.history.append(nxt)
        return nxt

    def rollback(self, n_ticks: int) -> Snapshot:
        """Tua lại n_ticks bước, cắt bỏ các Snapshot phía sau (không tính toán lại)."""
        if n_ticks < 0 or n_ticks >= len(self.history):
            raise ValueError("n_ticks không hợp lệ")
        target_index = len(self.history) - 1 - n_ticks
        self.history = self.history[: target_index + 1]
        return self.current

    def replay(self, inputs_sequence: List[Dict[str, Any]]) -> Snapshot:
        """Mô phỏng tới bằng cách áp dụng tuần tự một chuỗi inputs."""
        for inputs in inputs_sequence:
            self.tick(inputs)
        return self.current
