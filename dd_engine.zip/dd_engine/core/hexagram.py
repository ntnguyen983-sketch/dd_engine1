"""
core/hexagram.py — Hexagram Engine (S03 & S04).
Sinh quẻ gốc, tính Hào động, sinh quẻ biến. Xem mục 2.2 & 3.9 tài liệu gốc.
"""

from dataclasses import dataclass
from typing import Optional, Tuple

from .bagua import Quai, BAGUA_TABLE, bits_to_quai, gio_to_index


def normalize_to_quai_so(so_luong: int) -> int:
    """Quái số = Tổng định lượng mod 8, dư 0 -> quy ước 8."""
    r = so_luong % 8
    return 8 if r == 0 else r


def normalize_to_hao_dong(so_luong: int) -> int:
    """Hào động = Tổng định lượng mod 6, dư 0 -> quy ước 6."""
    r = so_luong % 6
    return 6 if r == 0 else r


def calc_active_line_z(x: int, y: int, gio: str) -> int:
    """z = ((x + y + Giờ - 1) mod 6) + 1"""
    gio_idx = gio_to_index(gio)
    return ((x + y + gio_idx - 1) % 6) + 1


@dataclass
class Hexagram:
    """Hexagram { upper, lower, active_line } — cấu trúc dữ liệu quẻ gốc (S04)."""
    upper: int
    lower: int
    active_line: int

    def __post_init__(self):
        for v, name in [(self.upper, "upper"), (self.lower, "lower")]:
            if not 1 <= v <= 8:
                raise ValueError(f"{name} phải trong 1..8, nhận {v}")
        if not 1 <= self.active_line <= 6:
            raise ValueError(f"active_line phải trong 1..6, nhận {self.active_line}")

    @property
    def upper_name(self) -> str:
        return BAGUA_TABLE[Quai(self.upper)]["name"]

    @property
    def lower_name(self) -> str:
        return BAGUA_TABLE[Quai(self.lower)]["name"]

    @property
    def bits(self) -> Tuple[int, int, int, int, int, int]:
        """6 hào từ dưới lên: (hạ quái 3 hào, thượng quái 3 hào)."""
        return BAGUA_TABLE[Quai(self.lower)]["bits"] + BAGUA_TABLE[Quai(self.upper)]["bits"]

    def spatial_index(self) -> float:
        """S: hào 1,2 -> 0.0 (Hạ) | hào 3,4 -> 0.5 (Trung) | hào 5,6 -> 1.0 (Thượng)."""
        if self.active_line in (1, 2):
            return 0.0
        if self.active_line in (3, 4):
            return 0.5
        return 1.0

    def bien_quai(self) -> "Hexagram":
        """Đảo hào tại active_line -> tái tạo Thượng/Hạ quái mới (Quẻ biến)."""
        bits = list(self.bits)
        idx = self.active_line - 1
        bits[idx] = 1 - bits[idx]
        new_lower = bits_to_quai(tuple(bits[0:3]))
        new_upper = bits_to_quai(tuple(bits[3:6]))
        return Hexagram(upper=new_upper, lower=new_lower, active_line=self.active_line)

    def to_dict(self) -> dict:
        return {
            "upper": int(self.upper), "lower": int(self.lower),
            "active_line": self.active_line,
            "upper_name": self.upper_name, "lower_name": self.lower_name,
            "spatial_index_S": self.spatial_index(),
        }

    def __repr__(self):
        return (f"Hexagram({self.lower_name} hạ / {self.upper_name} thượng, "
                f"hào {self.active_line} động)")


def build_hexagram(upper_quai: int, lower_quai: int, gio: str) -> Hexagram:
    """Khởi quẻ mặc định: Thượng/Hạ quái đã biết, tính Hào động theo z."""
    z = calc_active_line_z(upper_quai, lower_quai, gio)
    return Hexagram(upper=upper_quai, lower=lower_quai, active_line=z)


def build_hexagram_from_ambiguous_signal(
    tong_dinh_luong_thuong: int,
    tong_dinh_luong_ha: int,
    tong_dinh_luong_hao: Optional[int] = None,
    gio: Optional[str] = None,
) -> Hexagram:
    """Bồ khuyết Mai Hoa cho tín hiệu mơ hồ (mục 2.2 & 3.9)."""
    upper = normalize_to_quai_so(tong_dinh_luong_thuong)
    lower = normalize_to_quai_so(tong_dinh_luong_ha)
    if tong_dinh_luong_hao is not None:
        return Hexagram(upper=upper, lower=lower,
                         active_line=normalize_to_hao_dong(tong_dinh_luong_hao))
    elif gio is not None:
        return build_hexagram(upper, lower, gio)
    raise ValueError("Cần tong_dinh_luong_hao HOẶC gio để xác định Hào động.")
