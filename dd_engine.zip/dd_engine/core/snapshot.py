"""
core/snapshot.py — Snapshot–Kernel–Runtime Model (mục 3.3).

Snapshot ≡ Materialized Runtime State: toàn bộ trạng thái hệ thống tại một
Simulation Tick được vật chất hóa hoàn toàn vào đây. Không có state ẩn nào
tồn tại ngoài Snapshot (Stateless Engine).
"""

import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from .hexagram import Hexagram


@dataclass
class Snapshot:
    tick: int
    hexagram: Optional[Hexagram] = None
    nodes: Dict[str, Any] = field(default_factory=dict)     # Identity_ID -> DuyenNode
    edges: List[Any] = field(default_factory=list)          # danh sách Edge
    vector_khi: Optional[Any] = None                        # [S, D, I, F, T]
    momentum: float = 0.0                                   # M_t, xem A2
    history_log: List[str] = field(default_factory=list)
    timestamp: float = field(default_factory=time.time)     # sát-na quan sát (epoch seconds)

    def to_dict(self) -> dict:
        return {
            "tick": self.tick,
            "hexagram": self.hexagram.to_dict() if self.hexagram else None,
            "n_nodes": len(self.nodes),
            "n_edges": len(self.edges),
            "vector_khi": self.vector_khi,
            "momentum": self.momentum,
            "timestamp": self.timestamp,
        }

    def clone_for_next_tick(self) -> "Snapshot":
        """Chuẩn bị Snapshot(t+1) kế thừa dữ liệu lịch sử trước khi Kernel biến đổi."""
        return Snapshot(
            tick=self.tick + 1,
            hexagram=self.hexagram,
            nodes=dict(self.nodes),
            edges=list(self.edges),
            vector_khi=self.vector_khi,
            momentum=self.momentum,
            history_log=list(self.history_log),
            timestamp=time.time(),
        )

    def __repr__(self):
        return f"Snapshot(tick={self.tick}, nodes={len(self.nodes)}, edges={len(self.edges)}, M={self.momentum:.3f})"
