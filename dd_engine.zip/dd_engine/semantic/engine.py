"""
semantic/engine.py — SemanticEngine, cài đặt Tầng S07 (mục 2.4).

Đây là ranh giới nơi hệ thống LẦN ĐẦU được phép gán ngữ nghĩa (Duyên, Tượng,
Văn cảnh) — Tầng Khí (S06)/Analysis phía trước tuyệt đối không được làm việc
này (Firewall, mục 2.3 & Tiên đề A3).

interpret() nhận Snapshot (đã đóng băng) + Analysis (thuần số liệu), tra
nhãn theo semantic.rules (S07 Output Matrix - Phụ lục 5.2), rồi diễn dịch
tiếp sang các khía cạnh đời sống cụ thể. Bảng diễn dịch domain-specific bên
dưới là Hyperparameter/heuristic (A5) — CẦN tinh chỉnh dần bằng thực chứng,
không phải chân lý cố định.
"""

from dataclasses import dataclass
from typing import Dict

from ..core.plugin import SemanticPlugin
from ..core.snapshot import Snapshot
from ..reason.analysis import Analysis
from .rules import SemanticLabel, label_from_vector_khi

# Diễn giải gốc theo từng nhãn S07 (bám sát Phụ lục 5.2, chưa gán Cát/Hung)
_LABEL_MEANING = {
    SemanticLabel.TU: "Mật độ cao, đang tăng trưởng và hội tụ nguồn lực.",
    SemanticLabel.HOP: "Mật độ cao nhưng đang thu hẹp, khép kín cấu trúc.",
    SemanticLabel.TAN: "Mật độ lỏng lẻo, đang phát tán và mở rộng ranh giới.",
    SemanticLabel.LY: "Mật độ suy thoái, chia rẽ và suy giảm liên kết.",
    SemanticLabel.HIEN: "Biểu hiện rõ ràng, đã bộc phát ra ngoại cảnh.",
    SemanticLabel.AN: "Vẫn tiềm ẩn dưới bề mặt, đang tích tụ nội tại.",
    SemanticLabel.TRUNG_TINH: "Chưa đủ dữ liệu để xác định rõ xu hướng (vùng biên).",
}

# Gợi ý domain-specific theo nhãn — heuristic, chỉnh được qua config (A5)
_DOMAIN_TEMPLATES: Dict[SemanticLabel, Dict[str, str]] = {
    SemanticLabel.TU: {
        "career": "Cơ hội đang hội tụ, thích hợp để chủ động nắm bắt.",
        "finance": "Nguồn lực đang tụ lại, có thể xem xét đầu tư/khởi động.",
        "relationship": "Có tín hiệu gắn kết, gần gũi hơn với người xung quanh.",
    },
    SemanticLabel.HOP: {
        "career": "Nên củng cố những gì đang có thay vì mở rộng thêm.",
        "finance": "Ưu tiên giữ vốn, hạn chế phân tán nguồn lực.",
        "relationship": "Mối quan hệ đang khép lại ở phạm vi thân cận, ổn định.",
    },
    SemanticLabel.TAN: {
        "career": "Cơ hội đang mở rộng nhưng còn rời rạc, cần thời gian định hình.",
        "finance": "Dòng tiền có xu hướng phân tán, cần theo dõi sát.",
        "relationship": "Các mối quan hệ đang mở rộng nhưng chưa sâu sắc.",
    },
    SemanticLabel.LY: {
        "career": "Có dấu hiệu rạn nứt/suy giảm liên kết, nên thận trọng.",
        "finance": "Rủi ro thất thoát nguồn lực, không nên mạo hiểm lúc này.",
        "relationship": "Có nguy cơ xa cách, cần chủ động hàn gắn nếu muốn giữ.",
    },
    SemanticLabel.HIEN: {
        "career": "Vấn đề đã bộc lộ rõ ra bên ngoài, người khác đã nhận thấy.",
        "finance": "Kết quả tài chính đã rõ ràng, ít còn ẩn số.",
        "relationship": "Cảm xúc/ý định đã được thể hiện công khai.",
    },
    SemanticLabel.AN: {
        "career": "Cơ hội còn tiềm ẩn, chưa đến lúc bộc lộ ra ngoài.",
        "finance": "Nguồn lực đang tích lũy âm thầm, chưa nên vội hành động.",
        "relationship": "Tình cảm còn kín đáo, chưa được ngỏ lời rõ ràng.",
    },
    SemanticLabel.TRUNG_TINH: {
        "career": "Chưa đủ tín hiệu để kết luận, nên quan sát thêm.",
        "finance": "Thị trường/nguồn lực đang ở trạng thái trung tính.",
        "relationship": "Chưa có tín hiệu rõ ràng theo hướng nào.",
    },
}


@dataclass
class Meaning:
    label: str
    label_description: str
    career: str
    finance: str
    relationship: str
    trace: Dict[str, object]   # A4 — truy vết ngược: vector_khi -> label -> meaning

    def to_dict(self) -> dict:
        return {
            "label": self.label,
            "label_description": self.label_description,
            "career": self.career,
            "finance": self.finance,
            "relationship": self.relationship,
            "trace": self.trace,
        }


class SemanticEngine(SemanticPlugin):
    """Cài đặt mặc định của Tầng S07. Có thể thay bằng plugin khác qua
    DCGFEngine.register_semantic() mà không cần sửa DCGFEngine (UK8)."""

    def interpret(self, snapshot: Snapshot, analysis: Analysis) -> Meaning:
        label = label_from_vector_khi(snapshot.vector_khi)
        template = _DOMAIN_TEMPLATES[label]

        return Meaning(
            label=label.value,
            label_description=_LABEL_MEANING[label],
            career=template["career"],
            finance=template["finance"],
            relationship=template["relationship"],
            trace={
                "vector_khi": snapshot.vector_khi,
                "hexagram": snapshot.hexagram.to_dict() if snapshot.hexagram else None,
                "analysis": analysis.to_dict(),
            },
        )
