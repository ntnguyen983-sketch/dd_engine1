"""
semantic/rules.py — Bảng Tra Ánh Xạ Ngưỡng Ngữ Nghĩa (S07 Output Matrix),
đúng theo Phụ Lục 5.2 của tài liệu gốc:

    I >= 0.75 và D > 0   -> TỤ  (hội tụ nguồn lực)
    I >= 0.75 và D <= 0  -> HỢP (thu hẹp, khép kín cấu trúc)
    I <  0.30 và D > 0   -> TÁN (phát tán, mở rộng ranh giới)
    I <  0.30 và D <= 0  -> LY  (chia rẽ, suy giảm liên kết)
    S >= 0.70 và F > 0.5 -> HIỆN (biểu hiện rõ ràng)
    S <  0.30             -> ẨN  (tiềm ẩn dưới bề mặt)

Vùng còn lại (I trong [0.30, 0.75) mà không rơi vào HIỆN/ẨN) không được
tài liệu định nghĩa tường minh -> quy ước là TRUNG_TINH (vùng biên), tài
liệu ghi 'được bồ khuyết bằng quy tắc Nạp giáp, Thể Dụng, Ngũ hành'
(chưa cài đặt, để lại làm điểm mở rộng — M9 trong Ma Trận Trưởng Thành).
"""

from enum import Enum
from typing import List


class SemanticLabel(Enum):
    TU = "TỤ"
    HOP = "HỢP"
    TAN = "TÁN"
    LY = "LY"
    HIEN = "HIỆN"
    AN = "ẨN"
    TRUNG_TINH = "TRUNG_TÍNH"  # vùng biên, chưa có quy tắc tường minh (M9)


def label_from_vector_khi(vector_khi: List[float]) -> SemanticLabel:
    """
    vector_khi: [S, D, I, F, T] — áp bảng tra Phụ lục 5.2 theo đúng thứ tự
    ưu tiên đã liệt kê trong tài liệu (Mật độ/Hướng trước, Vị trí/Lực sau).
    """
    S, D, I, F, T = vector_khi

    if I >= 0.75 and D > 0:
        return SemanticLabel.TU
    if I >= 0.75 and D <= 0:
        return SemanticLabel.HOP
    if I < 0.30 and D > 0:
        return SemanticLabel.TAN
    if I < 0.30 and D <= 0:
        return SemanticLabel.LY
    if S >= 0.70 and F > 0.5:
        return SemanticLabel.HIEN
    if S < 0.30:
        return SemanticLabel.AN
    return SemanticLabel.TRUNG_TINH
