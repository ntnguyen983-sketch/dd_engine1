"""semantic — Tầng S07: Bảng ngưỡng ngữ nghĩa (Phụ lục 5.2) + SemanticEngine."""

from .rules import SemanticLabel, label_from_vector_khi
from .engine import SemanticEngine, Meaning

__all__ = ["SemanticLabel", "label_from_vector_khi", "SemanticEngine", "Meaning"]
