"""api — Điểm vào duy nhất của hệ thống: DCGFEngine."""

from .engine import DCGFEngine

__all__ = ["DCGFEngine"]
