"""
api/engine.py — DCGFEngine: bộ não điều phối toàn bộ pipeline DCGF.

Kiến trúc phân tầng (đúng đề xuất):
    Raw Input -> S01 Observation -> S02 Cognitive Filter -> S03 Structural
    Mapping -> S04 Hexagram Engine -> S05 Force Engine -> S06 Runtime
    -> S07 Semantic Engine -> S08 Strategy Engine -> Output

API thống nhất:
    result = engine.run(raw_input="gà gáy 4 âm", gio="Tý", nodes=..., edges=...)

Nguyên tắc Firewall Tầng Khí vẫn được giữ nguyên: observe() (S01-S06) CHỈ
tạo Snapshot thuần số liệu, không diễn giải. analyze() vẫn thuần toán học
(ngũ hành/xu thế/ổn định — không gán Cát/Hung). interpret() (S07) là nơi
ĐẦU TIÊN được phép gán ý nghĩa. recommend() (S08) sinh quyết định hành động.
"""

from typing import Any, Dict, Optional, Union

from ..core.hexagram import Hexagram
from ..core.snapshot import Snapshot
from ..core.runtime import Runtime, TickRecord
from ..core.plugin import SemanticPlugin, StrategyPlugin, PredictorPlugin, LLMPlugin
from ..mapping.mapper import StructuralMapper
from ..reason.node import DuyenNode
from ..reason.edge import Edge
from ..reason.force import compute_vector_khi, VectorKhi
from ..reason.analysis import analyze as analyze_fn, Analysis
from ..semantic.engine import SemanticEngine, Meaning
from ..strategy.engine import StrategyEngine, Decision


class DCGFEngine:
    def __init__(self):
        # S03/S04
        self.mapper = StructuralMapper()
        # S06
        self.runtime = Runtime()
        # S07 / S08 — mặc định dùng cài đặt chuẩn, có thể thay bằng plugin
        self.semantic: SemanticPlugin = SemanticEngine()
        self.strategy: StrategyPlugin = StrategyEngine()
        # Plugin mở rộng tùy chọn (không bắt buộc trong pipeline run() mặc định)
        self.predictors: Dict[str, PredictorPlugin] = {}
        self.llms: Dict[str, LLMPlugin] = {}

    # ------------------------------------------------------------------
    # Plugin Architecture (UK8 — Extensibility, không sửa Lõi Kernel)
    # ------------------------------------------------------------------
    def register_semantic(self, plugin: SemanticPlugin) -> None:
        if not isinstance(plugin, SemanticPlugin):
            raise TypeError("plugin phải kế thừa core.plugin.SemanticPlugin")
        self.semantic = plugin

    def register_strategy(self, plugin: StrategyPlugin) -> None:
        if not isinstance(plugin, StrategyPlugin):
            raise TypeError("plugin phải kế thừa core.plugin.StrategyPlugin")
        self.strategy = plugin

    def register_predictor(self, name: str, plugin: PredictorPlugin) -> None:
        if not isinstance(plugin, PredictorPlugin):
            raise TypeError("plugin phải kế thừa core.plugin.PredictorPlugin")
        self.predictors[name] = plugin

    def register_llm(self, name: str, plugin: LLMPlugin) -> None:
        if not isinstance(plugin, LLMPlugin):
            raise TypeError("plugin phải kế thừa core.plugin.LLMPlugin")
        self.llms[name] = plugin

    # ------------------------------------------------------------------
    # S01 -> S06 : Observation -> ... -> Runtime  (chỉ tạo Snapshot, KHÔNG diễn giải)
    # ------------------------------------------------------------------
    def observe(self, raw_input: Union[str, int, float, list],
                gio: Optional[str] = None,
                nodes: Optional[dict] = None,
                edges: Optional[list] = None) -> Snapshot:
        """
        S01 Observation -> S02 Cognitive Filter -> S03 Structural Mapping
        -> S04 Hexagram Engine -> S05 Force Engine -> S06 Runtime.tick()
        Trả về Snapshot thuần số liệu: Hexagram, VectorKhi, Node, Edge,
        Momentum, Timestamp. KHÔNG có diễn giải ngữ nghĩa ở bước này.
        """
        hexagram: Hexagram = self.mapper.map(raw_input, gio=gio)  # S03/S04

        nodes = nodes or {}
        edges = edges or []
        merged_nodes = dict(self.runtime.current.nodes)
        merged_nodes.update(nodes)
        merged_edges = list(self.runtime.current.edges) + list(edges)

        vector_khi: VectorKhi = compute_vector_khi(                # S05 Force Engine
            hexagram, merged_nodes, merged_edges,
            momentum=self.runtime.current.momentum,
        )

        inputs = {
            "hexagram": hexagram,
            "nodes": nodes,
            "edges": edges,
            "vector_khi": vector_khi.as_list(),
            "momentum_delta": vector_khi.F * 0.1,
        }
        return self.runtime.tick(inputs)                            # S06 Runtime

    # ------------------------------------------------------------------
    # Analyze() — vẫn thuần toán học/cấu trúc, CHƯA phải S07
    # ------------------------------------------------------------------
    def analyze(self, snapshot: Snapshot) -> Analysis:
        """Hexagram -> Ngũ hành -> Quan hệ -> Khí -> Xu thế -> Mức ổn định."""
        return analyze_fn(snapshot)

    # ------------------------------------------------------------------
    # S07 — Semantic Engine: LẦN ĐẦU gán ý nghĩa (Duyên/Tượng/Văn cảnh)
    # ------------------------------------------------------------------
    def interpret(self, snapshot: Snapshot, analysis: Analysis) -> Meaning:
        return self.semantic.interpret(snapshot, analysis)

    # ------------------------------------------------------------------
    # S08 — Strategy Engine: sinh khuyến nghị hành động
    # ------------------------------------------------------------------
    def recommend(self, snapshot: Snapshot, analysis: Analysis, meaning: Meaning) -> Decision:
        return self.strategy.recommend(snapshot, analysis, meaning)

    # ------------------------------------------------------------------
    # API thống nhất: run() — toàn bộ pipeline trong một lời gọi
    # ------------------------------------------------------------------
    def run(self, raw_input: Union[str, int, float, list],
            gio: Optional[str] = None,
            nodes: Optional[dict] = None,
            edges: Optional[list] = None) -> Dict[str, Any]:
        snapshot = self.observe(raw_input, gio=gio, nodes=nodes, edges=edges)
        analysis = self.analyze(snapshot)
        meaning = self.interpret(snapshot, analysis)
        decision = self.recommend(snapshot, analysis, meaning)

        # Runtime History: lưu Snapshot -> Analysis -> Meaning -> Decision
        # (nền tảng cho tự đánh giá S11: quẻ hôm qua đã luận gì, khuyến nghị
        # gì, kết quả thực tế ra sao — dùng runtime.set_actual_outcome() sau).
        self.runtime.record(snapshot.tick, analysis=analysis, meaning=meaning, decision=decision)

        return {
            "snapshot": snapshot,
            "analysis": analysis,
            "meaning": meaning,
            "decision": decision,
            "runtime": {
                "tick": snapshot.tick,
                "history": len(self.runtime.history),
            },
        }

    @property
    def current_snapshot(self) -> Snapshot:
        return self.runtime.current


if __name__ == "__main__":
    # Demo: tái hiện ca "Gà gáy 4 âm" (mục 4.4) qua toàn bộ pipeline S01->S08.
    engine = DCGFEngine()

    node_a = DuyenNode(identity_id="ga_gay")
    node_b = DuyenNode(identity_id="quan_sat_vien")
    edge_ab = Edge(edge_id="e1", source_id="ga_gay", target_id="quan_sat_vien",
                    weight=0.6, evidence="tín hiệu âm thanh gà gáy 4 âm")

    result = engine.run(
        raw_input="gà gáy 4 âm",
        gio="Tý",
        nodes={"ga_gay": node_a, "quan_sat_vien": node_b},
        edges=[edge_ab],
    )

    print("Snapshot :", result["snapshot"])
    print("Hexagram :", result["snapshot"].hexagram)
    print("Analysis :", result["analysis"].to_dict())
    print("Meaning  :", result["meaning"].to_dict())
    print("Decision :", result["decision"].to_dict())
    print("Runtime  :", result["runtime"])
