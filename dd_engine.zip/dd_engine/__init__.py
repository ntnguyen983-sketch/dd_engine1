"""
dd_engine — Cài đặt tham chiếu Kiến Trúc DCGF (Duyên Dịch: Dynamic
Condition & Graph Framework).

Cách dùng nhanh:

    from dd_engine import DCGFEngine

    engine = DCGFEngine()
    result = engine.run(raw_input="gà gáy 4 âm", gio="Tý")
    print(result["decision"])

Pipeline đầy đủ:
    Raw Input -> S01 Observation -> S02 Cognitive Filter -> S03 Structural
    Mapping -> S04 Hexagram Engine -> S05 Force Engine -> S06 Runtime
    -> S07 Semantic Engine -> S08 Strategy Engine -> Output
"""

from .api.engine import DCGFEngine
from .core.hexagram import Hexagram
from .core.snapshot import Snapshot
from .core.runtime import Runtime, TickRecord
from .reason.analysis import Analysis
from .semantic.engine import Meaning
from .strategy.engine import Decision

__version__ = "0.1.0"

__all__ = [
    "DCGFEngine",
    "Hexagram", "Snapshot", "Runtime", "TickRecord",
    "Analysis", "Meaning", "Decision",
    "__version__",
]
